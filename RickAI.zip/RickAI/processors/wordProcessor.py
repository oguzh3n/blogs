import json
import random
import wikipedia
import time
import os

wikipedia.set_lang("en")

with open('./data/words.json', 'r') as file:
    wordData = json.load(file)

with open('./data/greets.json', 'r') as file:
    greetData = json.load(file)

def readAllWords():
    return wordData

def findWords(sentence):
    words = sentence.lower().split()
    responses_list = []
    matched_keywords = []

    existing_questions = load_existing_questions()

    for main_word, data in wordData.items():
        if main_word in words or any(alias in words for alias in data.get('aliases', [])):
            if 'responses' in data:
                responses_list.extend(data['responses'])
            matched_keywords.append(main_word)

            # Alt kelimeleri kontrol et
            for sub_word in data.keys():
                if sub_word in words or any(alias in words for alias in data.get('aliases', [])):
                    if 'responses' in data[sub_word]:
                        responses_list.extend(data[sub_word]['responses'])

    question = ' '.join(words)
    if question in existing_questions:
        return existing_questions[question]

    if not responses_list:
        wikipedia_response = get_wikipedia_summary(sentence)
        if wikipedia_response:
            return wikipedia_response
        
        return "Sorry, I couldn't understand your question. Could you try rephrasing it?"

    return random.choice(responses_list)

def load_existing_questions():
    file_path = './data/rickBrain.json'
    if os.path.exists(file_path):
        with open(file_path, 'r') as file:
            try:
                existing_data = json.load(file)
                return {item['question']: item['answer'] for item in existing_data}
            except json.JSONDecodeError:
                return {}
    return {}

def get_wikipedia_summary(question):
    try:
        answer = wikipedia.summary(question, sentences=2)
        save_to_json(question, answer)
        return answer
    except wikipedia.exceptions.DisambiguationError as e:
        chosen_topic = random.choice(e.options)
        try:
            answer = wikipedia.summary(chosen_topic, sentences=2)
            save_to_json(chosen_topic, answer)
            return answer
        except wikipedia.exceptions.PageError:
            return "Sorry, I don't understand. Could you repeat that using the different words again please?"
    except wikipedia.exceptions.PageError:
        return "Sorry, I don't understand. Could you repeat that using the different words again please?"
    except Exception as e:
        return f"An error occurred in back-end services, please contact admin. #81PROCESSOR"

def save_to_json(question, answer):
    data = {
        "question": question,
        "answer": answer
    }

    file_path = './data/rickBrain.json'
    
    if os.path.exists(file_path):
        with open(file_path, 'r+') as file:
            try:
                existing_data = json.load(file)

                if any(item['question'] == question for item in existing_data):
                    return
                
                existing_data.append(data) 
                file.seek(0)
                json.dump(existing_data, file, indent=4)
                file.truncate()
            except json.JSONDecodeError:
                file.seek(0)
                json.dump([data], file, indent=4)
                file.truncate()
    else:
        with open(file_path, 'w') as file:
            json.dump([data], file, indent=4)

def getGreet():
    responses = greetData.get("greet", {}).get("responses", [])
    if responses:
        return random.choice(responses)
    else:
        return "Something went wrong in the back-end. #BAC24GREET"

def slow_typing(text, delay=0.03):
    for char in text:
        print(char, end='', flush=True)
        time.sleep(delay)