# Required Models
from flask import Flask, request, jsonify
from flask_cors import CORS
from flask_talisman import Talisman
import re
import json

# Rick AI Models
from processors.wordProcessor import findWords

# Web API
app = Flask(__name__)
CORS(app)
Talisman(app)

# Store asked questions
asked_questions = []

# Rick AI Main
def sanitize_input(user_input):
    return re.sub(r'<.*?>', '', user_input)

@app.route('/ask', methods=['POST'])
def ask_question():
    inputUser = request.args.get('query', '')
    
    inputUser = sanitize_input(inputUser)
    
    if inputUser:
        if inputUser in asked_questions:
            response_message = "You've already asked that question. Can I help you with something else?"
        else:
            asked_questions.append(inputUser)
            response_message = findWords(inputUser)
            
        return jsonify({"response": response_message}), 200
            
    return jsonify({"error": "No question provided."}), 400

if __name__ == '__main__':
    app.run(ssl_context='adhoc', debug=True)