const app = require("express").Router();
const blogsdb = require(`${process.cwd()}/src/database/models/blogs.js`);

console.log("[Datch.UK]: Blogs router loaded.");

app.get("/blogs", async (req, res) => {
  let x = await blogsdb.find({});
  res.render("blogs.ejs", {
    bot: global.Client,
    path: req.path,
    config: global.config,
    user: req.isAuthenticated() ? req.user : null,
    req: req,
    partners: x,
    roles: global.config.server.roles,
  });
});

module.exports = app;
