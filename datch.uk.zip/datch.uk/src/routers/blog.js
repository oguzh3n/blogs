const app = require("express").Router();
const blogsdb = require(`${process.cwd()}/src/database/models/blogs.js`);

console.log("[Datch.UK]: Blog router loaded.");

// /blog/:title route
app.get("/blog/:title", async (req, res) => {
  const blogTitle = req.params.title; // URL'den title alınıyor

  try {
    const blog = await blogsdb.findOne({ title: blogTitle }); // MongoDB'de title ile arama yapılır

    if (!blog) {
      // Blog bulunamazsa 404 durum kodu döndür ve mesaj göster
      return res.redirect("/blogs");
    }

    // Blog bulunduysa blog.ejs'ye yönlendirilir
    res.render("blog.ejs", {
      bot: global.Client,
      path: req.path,
      config: global.config,
      user: req.isAuthenticated() ? req.user : null,
      req: req,
      blog: blog, // Blog verisi ejs'ye aktarılıyor
    });
  } catch (err) {
    console.error(`[Datch.UK]: Error fetching blog: ${err.message}`);
    res.redirect("/blogs");
  }
});

module.exports = app;
