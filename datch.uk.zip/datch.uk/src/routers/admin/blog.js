const app = require("express").Router();
const channels = global.config.server.channels;
const path = require("path");
const config = require("../../../config.js");
console.log("[Datch.UK]: Admin/Blog router loaded.");
const client = global.Client;
const partnerdb = require(`${process.cwd()}/src/database/models/blogs.js`);

app.get("/admin/blogs", global.checkAuth, async (req, res) => {
  if (!config.bot.owners.includes(req.user.id)) return res.redirect("../admin");
  let x = await partnerdb.find(); 
  res.render("admin/administrator/blogs.ejs", {
    bot: global.Client,
    path: req.path,
    config: global.config,
    user: req.isAuthenticated() ? req.user : null,
    req: req,
    roles: global.config.server.roles,
    channels: global.config.server.channels,
    blogs: x,
  });
});

app.post("/admin/blogs/delete/:id", async (req, res) => {
  try {
    await partnerdb.findByIdAndDelete(req.params.id);
    res.redirect("/admin/blogs?success=true&message=Blog%20deleted%20successfully");
  } catch (err) {
    console.log(err);
    res.redirect("/admin/blogs?error=true&message=Error%20deleting%20blog");
  }
});

app.post("/admin/blogs", global.checkAuth, async (req, res) => {
  try {
  if (!config.bot.owners.includes(req.user.id)) return res.redirect("../admin");
  await new partnerdb({
    title: req.body.serverName || null,
    description: req.body.partnerDesc || null,
    icon: req.body.icon || null,
    imageURL: req.body.imageURL || null,
  }).save();
  
  return res.redirect("/admin/blogs?success=true&message=Blog added.");
  } catch (e) {
    console.log(e);
    return res.redirect("/admin/blogs?error=true&message=An unknown error occurred.");
  }
});

module.exports = app;

function createID(length) {
  var result = "";
  var characters = "123456789";
  var charactersLength = characters.length;
  for (var i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * charactersLength));
  }
  return result;
}
