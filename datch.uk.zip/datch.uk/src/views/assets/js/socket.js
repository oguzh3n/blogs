const socket = io.connect("https://Datch.UK");

socket.on("userCount", (userCount) => {
  let doc = document.getElementById("connectionCount");
  if (doc) {
    doc.innerHTML = userCount;
  }
});
