const config = require("../../config.js");
const mongoose = require("mongoose");

module.exports = async () => {
  mongoose
    .connect(config.bot.mongourl, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
      autoIndex: false,
    })
    .then(() => {
      console.log("[Datch.UK]: Mongoose successfully connected.");
    })
    .catch((err) =>
      console.log(
        "[Datch.UK]: An error occurred while connecting mongoose.",
        err
      )
    );
};
