const mongoose = require("mongoose");
let hm = new mongoose.Schema({
  title: { type: String, default: null },
  description: { type: String, default: null },
  imageURL: { type: String, default: null },
  icon: { type: String, default: null},
});

module.exports = mongoose.model("blogs", hm);
