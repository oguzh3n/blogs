module.exports = {
  bot: {
    token: "MTA2NjczNDg4MzA1OTI5MDE2Mg.GmJaLP.GxVA3oo2piw-yTcpIiJ8S1PRfVptXl4wOPzYKs", // Bot List Bot Token from https://discord.com/developers/applications
    owners: ["860229283598827540"],
    mongourl: "mongodb+srv://oguz:NhqZayGsBPVoWWW@lenyuk.kgglj.mongodb.net/?retryWrites=true&w=majority&appName=LenyUK", //https://mongodb.com/cloud/atlas/register
    servers: {
      token: "MTE0NTI2MzA4NTY3OTAzMDI3Mw.GQ1yzd.DOr0ckrt1iajlda1rWelkvhdBVpuzPduMorDUU" // Server List Bot Token
    },
  },

  website: {
    announcement: "Contact us from our Discord server for partnership.",
    announcementIcon: "handshake",
    callback: "https://www.datch.uk/callback", //example : https://test.com/callback avoid / at last.
    secret: "2cHZiMwHKIEIzIPmjtbl4BUxsXDCfjjg",
    clientID: "1066734883059290162", // Bot client id.
    tags: [
      "Moderation",
      "Fun",
      "Minecraft",
      "Economy",
      "Guard",
      "NSFW",
      "Anime",
      "Invite",
      "Music",
      "Logging",
      "Web Dashboard",
      "Reddit",
      "Youtube",
      "Twitch",
      "Crypto",
      "Leveling",
      "Game",
      "Roleplay",
      "Utility",
      "Turkish",
    ],
    languages: [
      { flag: "gb", code: "en", name: "English" },
      { flag: "tr", code: "tr", name: "Türkçe" },
      { flag: "de", code: "de", name: "Deutsch" },
    ],
    servers: {
      tags: [
        {
          icon: "fal fa-code",
          name: "Development",
        },
        {
          icon: "fal fa-play",
          name: "Stream",
        },
        {
          icon: "fal fa-camera",
          name: "Media",
        },
        {
          icon: "fal fa-building",
          name: "Company",
        },
        {
          icon: "fal fa-gamepad",
          name: "Game",
        },
        {
          icon: "fal fa-icons",
          name: "Emoji",
        },
        {
          icon: "fal fa-robot",
          name: "Bot List",
        },
        {
          icon: "fal fa-server",
          name: "Server List",
        },
        {
          icon: "fal fa-moon-stars",
          name: "Turkish",
        },
        {
          icon: "fab fa-discord",
          name: "Support",
        },
        {
          icon: "fal fa-volume",
          name: "Sound",
        },
        {
          icon: "fal fa-comments",
          name: "Chatting",
        },
        {
          icon: "fal fa-lips",
          name: "NSFW",
        },
        {
          icon: "fal fa-comment-slash",
          name: "Challange",
        },
        {
          icon: "fal fa-hand-rock",
          name: "Protest",
        },
        {
          icon: "fal fa-headphones-alt",
          name: "Roleplay",
        },
        {
          icon: "fal fa-grin-alt",
          name: "Meme",
        },
        {
          icon: "fal fa-shopping-cart",
          name: "Shop",
        },
        {
          icon: "fal fa-desktop",
          name: "Technology",
        },
        {
          icon: "fal fa-laugh",
          name: "Fun",
        },
        {
          icon: "fal fa-share-alt",
          name: "Social",
        },
        {
          icon: "fal fa-laptop",
          name: "E-Spor",
        },
        {
          icon: "fal fa-palette",
          name: "Design",
        },
        {
          icon: "fal fa-users",
          name: "Community",
        },
      ],
    },
  },

  server: {
    id: "983132734820081694",
    channelWelcome: "1325152281464668201",
    invite: "https://discord.gg/tCs38MF6YU",
    roles: {
      administrator: "1071467422185439242",
      moderator: "1071467429940695061",
      profile: {
        sitecreator: "1071467415629746186",
        booster: "",
        sponsor: "1324836840750190612",
        supporter: "1071467438178312222",
        partnerRole: "1221556776244347001",
      },
      botlist: {
        developer: "1133055816589639681",
        certified_developer: "1146210441014546472",
        bot: "1125195734426320947", // This is not your Bot ID, This is the Role ID Approved Bots get when they join your server
        certified_bot: "1133055801846677604",
      },
    },
    channels: {
      codelog: "1323712344710447176",
      login: "1323712344710447176",
      webstatus: "1323712344710447176",
      uptimelog: "1323712344710447176",
      botlog: "1323673235526520833",
      votes: "1323712344710447176",
      reportlog: "1323712344710447176"
    },
  },
};
